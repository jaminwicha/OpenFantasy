# OpenFantasy — Milestone 8: *The Wide Water*

**Version:** 1.0 · **Date:** 2026-08-17 · **Builds on:** M7 (`2b24e0c`), M7.5+8A/8B (`48d8d85`) ·
**Plan:** `RUNTIME_SEED_IMPLEMENTATION_PLAN.md` phases 8A–8D

## Theme

The world stops ending. Beyond Aldermere's coast the ocean now runs to the
horizon — procedurally, deterministically, identically on every client — with
frontier continents, seed-born settlements that trade and post bounties, wild
biome fauna, and two new adventure-site families. Everything derives from
`(WorldSeed, coordinates, domain)`; nothing procedural is stored.

## What shipped

### M7.5 polish (with 8A/8B in `48d8d85`)
- **Delve tile art** (atlas row 6): stairs, chests, doors + locks, rubble,
  slag, chasm, and the **cracked-wall tell** for secret seams; three visible
  **sewer grates** stamped into Brasshollow (gen_world).
- **Character sheet (P)**: effective stats + XP-to-next over PlayerState.
- Style-aware delve spawn density — set-piece floors calm, xandered floors
  dense (GeneratorVersion 2).
- **Corner-aware blob autotiling**: corner-mask overlay rows (7/8) + a third
  TileMapLayer round off shorelines and grass fringe (roadmap Phase 2 core).

### 8A — The chunk seam
`WorldMap` stores the authored 512×512 map as 32×32 chunks behind the same
`TileAt` API, gated on a pinned FNV hash — provably byte-identical — with a
frontier source hook for everything beyond the bounds.

### 8B — The procedural frontier
- `FrontierGen`: biome fields → tiles through the chunk seam; forced-ocean
  blend ring hugs the authored coast (D6); hard bound at ±1M tiles (D2).
- World seed rides the Welcome (protocol v6); **clients generate frontier
  terrain locally** and stream chunks around the camera (D5).
- **Per-player interest radius** on overworld snapshots (96 tiles) — the
  frontier is unbounded, so zone-wide broadcasts had to go; state hash
  computed once per broadcast.
- Floor-division fixes for negative tile coordinates; vehicles sail off the
  map edge and keep going.

### 8C — Seed-born settlements
- `SettlementGen` (pure, shared): placement over 128-tile site cells,
  hamlet/village/town tiers, plaza + ring-road + building layouts stamped
  into frontier chunks, phoneme names (Oakhaven, Frostwatch…).
- `World.Settlements` (server): as players approach, the roster spawns —
  seed-derived names, paper-doll faces, biome-flavored dialog, tier-banded
  **shops stocked from the shipped item data**, and rumor lines pointing at
  *real* neighboring settlements (§2 coherence rule).
- **Daily bounty contracts** (D10 day index): innkeepers/elders post generated
  cull quests against monsters that actually roam the frontier; quest names
  and progress lines render server-side so generated content needs no client
  data files.
- **Wild frontier fauna**: biome-keyed monster packs populate around
  travelers and sweep away when everyone leaves (pure → nothing is lost).

### 8D — Site families & cyclic motifs
- **Cyclic motif planner**: every non-set-piece floor draws a motif —
  TwoRoute, LockKeyLoop (proof-checked lock near the goal), HiddenShortcut
  (extra secret, relaxed detour), DangerousDetour (hazard lane) — the first
  slice of the plan's cyclic-grammar layer, riding the invariant validator.
- **Temple family** (`TempleEmbedder`): mirrored plan, central nave, flanking
  processional rings (cycles by construction), hidden sanctum with treasure
  behind the altar. Live as **the Sanctum of Stones** beneath the standing
  stones POI.
- **CavernBreach zonal blend**: Hollow Mine's man-made west now breaks
  through into eroded living cavern on the east (fill-only-walls
  breakthroughs — connectivity-monotone, never paves over stairs).
- **The Ruined Watchtower**: a third new live site — 3 collapsed stories of
  rubble above the wilds (GeneratorVersion 3, goldens re-pinned).

## Verification

- `--selftest`: **40 passed, 0 failed** — includes the 8A byte-identity gate,
  frontier determinism/sailability/bounds, settlement populate→trade→bounty
  loop, temple sanctum assertions, and all M1–M7 suites unchanged.
- Probe battery: all registry sites × 30 seeds × all floors — determinism +
  honest-route proofs hold across both families and all motifs.
- Two-bot multiplayer smoke green on protocol v6; `--auto` playtest
  screenshot green.

## Deferred (tracked for M9)

- Atlas of Aldermere (discovery log), cartographer renown, waystones, land
  claims — the meaning layer rides the stable IDs everything now has.
- Frontier adventure-site placement (delves out in the wilds) and the full
  cyclic grammar with keyed locks; castle/forest/grotto families.
- Settlement persistence deltas (shop purchases currently reset on restock;
  contract history unpersisted) — the D4 GeneratorVersion stamps are ready.
