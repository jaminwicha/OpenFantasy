namespace OpenFantasy.Sim.SiteGen;

/// <summary>
/// Temple structural family (8D, plan §3.5): a mirrored plan around a central
/// nave — entrance hall at the south, altar at the north, side chapels
/// connected by processional rings on both flanks (the rings + nave form the
/// floor's cycles by construction), and a hidden sanctum behind the altar
/// reached only through a secret seam. Symmetry is the family's signature;
/// the shared door/secret/spawn passes and the validator ride unchanged.
/// </summary>
public static class TempleEmbedder
{
    public static SiteFloor Embed(XorShift64 rng, SiteRecipe recipe, SiteStyle style, bool bossFloor, CycleMotif motif)
    {
        int w = recipe.Width, h = recipe.Height;
        var f = new SiteFloor
        {
            Width = w,
            Height = h,
            Tiles = new SiteTile[w * h],
            Motif = motif,
        };
        int mid = w / 2;

        // Entrance hall (south) and altar hall (north) sit on the axis;
        // the altar leaves headroom for the sanctum behind it.
        var entranceRoom = AddRoom(f, mid - 3, h - 8, 7, 5);
        var altarRoom = AddRoom(f, mid - 4, 6, 9, 6);

        // The nave: a 3-wide processional from hall to altar.
        for (int y = altarRoom.Y + altarRoom.H; y < entranceRoom.Y; y++)
            for (int dx = -1; dx <= 1; dx++)
                f.Set(mid + dx, y, SiteTile.Floor);

        // Side chapels, mirrored across the axis.
        int chapels = Math.Max(3, style.RoomTarget() / 4);
        int yTop = altarRoom.Y + altarRoom.H + 2;
        int yBot = entranceRoom.Y - 3;
        for (int i = 0; i < chapels; i++)
        {
            int cw = rng.Range(5, 7);
            int ch = rng.Range(4, 5);
            int y = yTop + (yBot - yTop) * i / Math.Max(1, chapels - 1) - ch / 2;
            y = Math.Clamp(y, 2, h - ch - 2);
            int x = rng.Range(4, Math.Max(5, mid - cw - 6));
            var left = AddRoom(f, x, y, cw, ch);
            var right = AddRoom(f, w - x - cw, y, cw, ch);
            // Chapels open onto the nave.
            RoomScatterEmbedder.CarveH(f, left.Center.X, mid, left.Center.Y);
            RoomScatterEmbedder.CarveH(f, mid, right.Center.X, right.Center.Y);
        }

        // Processional rings: one corridor down each flank stitching the
        // chapels and both halls together — two cycles by construction.
        int leftCol = 3, rightCol = w - 4;
        int ringTop = altarRoom.Y + 2, ringBot = entranceRoom.Y + 2;
        RoomScatterEmbedder.CarveV(f, ringTop, ringBot, leftCol);
        RoomScatterEmbedder.CarveV(f, ringTop, ringBot, rightCol);
        RoomScatterEmbedder.CarveH(f, leftCol, altarRoom.Center.X, ringTop);
        RoomScatterEmbedder.CarveH(f, altarRoom.Center.X, rightCol, ringTop);
        RoomScatterEmbedder.CarveH(f, leftCol, entranceRoom.Center.X, ringBot);
        RoomScatterEmbedder.CarveH(f, entranceRoom.Center.X, rightCol, ringBot);
        foreach (var room in f.Rooms)
        {
            if (room == entranceRoom || room == altarRoom) continue;
            int col = room.Center.X < mid ? leftCol : rightCol;
            RoomScatterEmbedder.CarveH(f, col, room.Center.X, room.Center.Y);
        }
        f.Loops = 2; // left ring + right ring, each closed through the nave

        // Entry, goal, landmark.
        f.Entry = entranceRoom.Center;
        f.Set(f.Entry.X, f.Entry.Y, SiteTile.StairsUp);
        var goal = altarRoom.Center;
        f.StairsDown = goal;
        if (bossFloor) f.Boss = goal;
        else f.Set(goal.X, goal.Y, SiteTile.StairsDown);
        f.Landmark = altarRoom.Center;

        // The hidden sanctum: a treasure room behind the altar, reached only
        // through a secret seam in the north wall (never load-bearing — the
        // goal is the altar itself).
        int sx = Math.Clamp(goal.X - 2, 2, w - 7);
        var sanctum = new Room { X = sx, Y = altarRoom.Y - 4, W = 5, H = 3 };
        for (int y = sanctum.Y; y < sanctum.Y + sanctum.H; y++)
            for (int x = sanctum.X; x < sanctum.X + sanctum.W; x++)
                f.Set(x, y, SiteTile.Floor);
        f.Set(goal.X, altarRoom.Y - 1, SiteTile.SecretDoor);
        var chest = new Pt(sanctum.X + sanctum.W / 2, sanctum.Y + sanctum.H / 2);
        f.Set(chest.X, chest.Y, SiteTile.Chest);
        f.Chests.Add(chest);

        RoomScatterEmbedder.PlaceDoors(f, rng, style);
        int goalRoom = f.Rooms.IndexOf(altarRoom);
        if (motif == CycleMotif.DangerousDetour)
            RoomScatterEmbedder.CarveChannel(f, entranceRoom.Center, altarRoom.Center, SiteTile.Water, rng);
        RoomScatterEmbedder.PlaceSpawnsAndChests(f, rng, goalRoom, bossFloor, style);
        return f;
    }

    private static Room AddRoom(SiteFloor f, int x, int y, int w, int h)
    {
        var room = new Room { X = x, Y = y, W = w, H = h };
        for (int yy = y; yy < y + h; yy++)
            for (int xx = x; xx < x + w; xx++)
                f.Set(xx, yy, SiteTile.Floor);
        f.Rooms.Add(room);
        return room;
    }
}
