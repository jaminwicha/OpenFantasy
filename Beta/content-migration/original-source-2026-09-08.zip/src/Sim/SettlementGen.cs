namespace OpenFantasy.Sim;

/// <summary>
/// Frontier settlement synthesis (8C): placement over a 128-tile site-cell
/// grid, tiered layouts stamped into frontier chunks, phoneme names, and NPC
/// roster spots — all pure functions of the world seed (design §3.1, D8).
/// Shared by server (population, shops, contracts) and client (terrain
/// stamping must agree tile-for-tile).
/// </summary>
public sealed class Settlement
{
    public required int CellX, CellY;
    public required int CX, CY;          // center tile
    /// <summary>0 hamlet · 1 village · 2 town.</summary>
    public required int Tier;
    public required string Name;
    public required int PatchHalf;
    public required int[] Patch;         // (2·half)² tile ids, -1 = passthrough
    /// <summary>NPC posts: tile pos, role, building index.</summary>
    public readonly List<(int tx, int ty, string role)> NpcSpots = new();
    public ulong Seed;

    public string Id => $"stl:{CellX}:{CellY}";
}

public sealed class SettlementGen
{
    public const int CellSize = 128;

    private static readonly string[] NameA =
    {
        "Oak", "Ash", "Ember", "Frost", "Storm", "Bright", "Moss", "Stone",
        "Salt", "Wind", "Thorn", "Fen", "Gale", "Iron", "Raven", "Elder",
    };
    private static readonly string[] NameB =
    {
        "haven", "wick", "stead", "ford", "gate", "watch", "fall", "mere",
        "brook", "field", "rest", "march",
    };

    private readonly ulong _seed;
    private readonly BiomeField _field;
    private readonly WorldMap _map;
    private readonly Dictionary<long, Settlement?> _cells = new();
    private readonly int _plaza, _road, _wall, _plank, _counter, _forge;

    public SettlementGen(WorldMap map, ulong worldSeed)
    {
        _map = map;
        _seed = StableId.Domain(worldSeed, "settlement");
        _field = new BiomeField(worldSeed);
        _plaza = map.TileIdByName("town_floor");
        _road = map.TileIdByName("road");
        _wall = map.TileIdByName("wall");
        _plank = map.TileIdByName("plank_floor");
        _counter = map.TileIdByName("counter");
        _forge = map.TileIdByName("forge");
    }

    /// <summary>Settlement in a site cell, or null. Cached; pure per seed.</summary>
    public Settlement? InCell(int cellX, int cellY)
    {
        long key = ((long)cellX << 32) ^ (uint)cellY;
        if (_cells.TryGetValue(key, out var cached)) return cached;
        var s = Build(cellX, cellY);
        _cells[key] = s;
        return s;
    }

    /// <summary>Layout override for a frontier tile, or -1.</summary>
    public int TileOverride(int tx, int ty)
    {
        var s = InCell(FloorDiv(tx), FloorDiv(ty));
        if (s is null) return -1;
        int dx = tx - s.CX + s.PatchHalf, dy = ty - s.CY + s.PatchHalf;
        int n = s.PatchHalf * 2;
        if (dx < 0 || dy < 0 || dx >= n || dy >= n) return -1;
        return s.Patch[dy * n + dx];
    }

    private static int FloorDiv(int t) => t >= 0 ? t / CellSize : (t - CellSize + 1) / CellSize;

    private Settlement? Build(int cellX, int cellY)
    {
        // Cells that touch the static map or its sea ring never settle.
        int x0 = cellX * CellSize, y0 = cellY * CellSize;
        if (x0 + CellSize > -FrontierGen.BlendBand - 8 && x0 < _map.Width + FrontierGen.BlendBand + 8 &&
            y0 + CellSize > -FrontierGen.BlendBand - 8 && y0 < _map.Height + FrontierGen.BlendBand + 8)
            return null;

        ulong h = StableId.Combine(_seed, cellX, cellY);
        if (h % 4 != 0) return null; // ~25% of cells host a settlement

        int tier = (int)(StableId.Mix(h + 1) % 10) switch { < 5 => 0, < 8 => 1, _ => 2 };
        int half = tier switch { 0 => 10, 1 => 13, _ => 16 };
        int cx = x0 + half + 4 + (int)(StableId.Mix(h + 2) % (ulong)(CellSize - 2 * half - 8));
        int cy = y0 + half + 4 + (int)(StableId.Mix(h + 3) % (ulong)(CellSize - 2 * half - 8));

        // Only buildable ground takes a settlement.
        var biome = _field.Classify(cx, cy);
        if (biome is not (Biome.Grassland or Biome.Forest or Biome.Desert
            or Biome.Snowfield or Biome.Jungle or Biome.Hills))
            return null;

        var s = new Settlement
        {
            CellX = cellX,
            CellY = cellY,
            CX = cx,
            CY = cy,
            Tier = tier,
            Name = NameA[StableId.Mix(h + 4) % (ulong)NameA.Length] +
                   NameB[StableId.Mix(h + 5) % (ulong)NameB.Length],
            PatchHalf = half,
            Patch = new int[(2 * half) * (2 * half)],
            Seed = StableId.Mix(h + 6),
        };
        Array.Fill(s.Patch, -1);
        Stamp(s);
        return s;
    }

    private void Stamp(Settlement s)
    {
        int half = s.PatchHalf, n = half * 2;
        void Set(int dx, int dy, int t)
        {
            int px = dx + half, py = dy + half;
            if (px >= 0 && py >= 0 && px < n && py < n)
                s.Patch[py * n + px] = t;
        }

        // Plaza + a road ring the buildings face.
        int plazaR = 2 + s.Tier;
        for (int dy = -plazaR; dy <= plazaR; dy++)
            for (int dx = -plazaR; dx <= plazaR; dx++)
                Set(dx, dy, _plaza);
        int ringR = plazaR + 2;
        for (int d = -ringR; d <= ringR; d++)
        {
            Set(d, -ringR, _road);
            Set(d, ringR, _road);
            Set(-ringR, d, _road);
            Set(ringR, d, _road);
        }

        // Buildings on ring slots, doors facing the plaza.
        int buildings = s.Tier switch { 0 => 3, 1 => 5, _ => 8 };
        int br = ringR + 4;
        var slots = new (int dx, int dy)[]
        {
            (0, -br), (br, 0), (0, br), (-br, 0),
            (br - 1, -br + 1), (br - 1, br - 1), (-br + 1, br - 1), (-br + 1, -br + 1),
        };
        int rot = (int)(s.Seed % 8);
        var roles = RolesFor(s.Tier);
        for (int i = 0; i < buildings && i < slots.Length; i++)
        {
            var (bx, by) = slots[(i + rot) % slots.Length];
            // 5×4 shell: wall border, plank interior, door toward the plaza.
            for (int dy = -2; dy <= 1; dy++)
                for (int dx = -2; dx <= 2; dx++)
                    Set(bx + dx, by + dy, dy == -2 || dy == 1 || dx == -2 || dx == 2 ? _wall : _plank);
            // Door punched through the wall on the plaza-facing side.
            if (Math.Abs(bx) >= Math.Abs(by)) Set(bx + 2 * Math.Sign(-bx), by, _plank);
            else Set(bx, by + (by > 0 ? -2 : 1), _plank);
            string role = i < roles.Length ? roles[i] : "villager";
            if (role is "trader" or "smith" or "inn")
                Set(bx, by - 1, _counter);
            if (role == "smith")
                Set(bx + 1, by, _forge);
            s.NpcSpots.Add((s.CX + bx, s.CY + by, role));
        }
        // Plaza wanderers.
        s.NpcSpots.Add((s.CX + 1, s.CY + 1, "villager"));
        if (s.Tier > 0) s.NpcSpots.Add((s.CX - 1, s.CY - plazaR + 1, "villager"));

        // The elder holds the plaza's north edge.
        s.NpcSpots.Add((s.CX, s.CY - plazaR, "elder"));
    }

    private static string[] RolesFor(int tier) => tier switch
    {
        0 => new[] { "trader", "villager", "villager" },
        1 => new[] { "inn", "trader", "villager", "villager", "villager" },
        _ => new[] { "inn", "trader", "smith", "villager", "villager", "villager", "villager", "villager" },
    };

    // ------------------------------------------------------------- names

    private static readonly string[] FirstA =
    {
        "Ael", "Bran", "Cor", "Dun", "El", "Fen", "Gil", "Hal",
        "Ida", "Jor", "Kel", "Lun", "Mor", "Nia", "Ol", "Pia",
    };
    private static readonly string[] FirstB =
    {
        "a", "in", "or", "ys", "an", "ette", "ric", "wen", "da", "mund", "la", "th",
    };

    public static string PersonName(ulong h)
        => FirstA[StableId.Mix(h) % (ulong)FirstA.Length] +
           FirstB[StableId.Mix(h + 1) % (ulong)FirstB.Length];
}
