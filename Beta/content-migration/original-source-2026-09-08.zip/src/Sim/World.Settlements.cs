namespace OpenFantasy.Sim;

/// <summary>
/// 8C server-side settlement life: as players approach a frontier settlement
/// its roster spawns — seed-derived names, faces, shops themed by tier and
/// biome, tavern rumors, and a daily cull contract (D10 sim calendar).
/// Frontier wilds likewise populate with biome monsters around travelers and
/// thin out again when everyone leaves. All input-driven → deterministic.
/// </summary>
public sealed partial class World
{
    private FrontierGen _frontier = null!;
    private BiomeField _frontierBiomes = null!;
    private readonly HashSet<long> _populatedSettlements = new();
    private readonly Dictionary<long, List<int>> _wildCells = new(); // pop cell → monster ids
    private const int WildCell = 64;             // tiles
    private const int WildDespawnRadius = 220 * SimConstants.UnitsPerTile / 32; // tiles

    /// <summary>Sim day index for restocks/contracts (never wall clock, D10).</summary>
    public int DayIndex => Tick / SimConstants.TicksPerDay;

    /// <summary>The pure settlement generator (tests, tooling, atlas).</summary>
    public SettlementGen FrontierSettlements => _frontier.Settlements;

    /// <summary>Called from Step() on a stagger: populate near players.</summary>
    private void TickFrontierLife()
    {
        if (Tick % 20 != 0) return;
        foreach (int playerId in _playerIds)
        {
            var p = _entities[playerId];
            if (p.MapId != 0) continue;
            int tx = SimConstants.TileOf(p.X), ty = SimConstants.TileOf(p.Y);
            if (Data.Map.InStaticBounds(tx, ty)) continue;

            int cellX = FloorDiv(tx, SettlementGen.CellSize);
            int cellY = FloorDiv(ty, SettlementGen.CellSize);
            for (int dy = -1; dy <= 1; dy++)
                for (int dx = -1; dx <= 1; dx++)
                    if (_frontier.Settlements.InCell(cellX + dx, cellY + dy) is { } s)
                        PopulateSettlement(s);

            PopulateWilds(tx, ty);
        }
        if (Tick % 200 == 0) SweepWilds();
    }

    private static int FloorDiv(int v, int size) => v >= 0 ? v / size : (v - size + 1) / size;

    // ------------------------------------------------------------- settlements

    private void PopulateSettlement(Settlement s)
    {
        long key = ((long)s.CellX << 32) ^ (uint)s.CellY;
        if (!_populatedSettlements.Add(key)) return;

        int u = SimConstants.UnitsPerTile;
        var biome = _frontierBiomes.Classify(s.CX, s.CY);
        for (int i = 0; i < s.NpcSpots.Count; i++)
        {
            var (tx, ty, role) = s.NpcSpots[i];
            ulong h = StableId.Combine(s.Seed, (ulong)i);
            string defId = $"gen:{role}:{s.Id}:{i}";
            var def = new NpcDef
            {
                Id = defId,
                Name = role == "elder" ? $"Elder {SettlementGen.PersonName(h)}" : SettlementGen.PersonName(h),
                Dialog = RoleDialog(role, s, biome),
                Wander = role == "villager" ? 3 : 0,
                Shop = ShopStock(role, s.Tier, h),
            };
            foreach (string line in RumorLines(role, s))
                def.Dialogs.Add(line);
            Data.Npcs[defId] = def; // idempotent registration (stable id)

            var appearance = new Appearance
            {
                Race = (byte)(StableId.Mix(h + 9) % 4),
                Skin = (byte)(StableId.Mix(h + 10) % 8),
                HairStyle = (byte)(StableId.Mix(h + 11) % 12),
                HairColor = (byte)(StableId.Mix(h + 12) % 16),
                Outfit = (byte)(StableId.Mix(h + 13) % 10),
                OutfitA = (byte)(StableId.Mix(h + 14) % 16),
                OutfitB = (byte)(StableId.Mix(h + 15) % 16),
                Acc = (byte)(StableId.Mix(h + 16) % 4),
            }.Sanitized(Data.Appearance);

            var e = new Entity
            {
                Id = _nextEntityId++,
                Kind = EntityKind.Npc,
                Name = def.Name,
                ArchetypeId = "",
                NpcDefId = defId,
                MoveSpeed = 2,
                HasAppearance = true,
                Appearance = appearance,
                X = tx * u + u / 2,
                Y = ty * u + u / 2,
                Hp = 1,
                MaxHp = 1,
                Level = 1,
                Speed = 1,
            };
            e.HomeX = e.X;
            e.HomeY = e.Y;
            _entities[e.Id] = e;
            _entityOrder.Add(e.Id);
        }
    }

    private string RoleDialog(string role, Settlement s, Biome biome) => role switch
    {
        "elder" => $"Welcome to {s.Name}, stranger. Few travelers reach us out here.",
        "inn" => $"The hearth of {s.Name} is always lit. Ask around — folk talk.",
        "trader" => "Wares from the wilds — have a look.",
        "smith" => "Forged right here. The frontier dulls a blade fast.",
        _ => biome switch
        {
            Biome.Snowfield or Biome.Glacier => "Cold enough to crack iron, most nights.",
            Biome.Desert or Biome.Canyon => "Mind the sun. It keeps its own bestiary.",
            Biome.Swamp or Biome.Jungle => "Stay off the soft ground after rain.",
            _ => $"Not much happens in {s.Name}. We like it that way.",
        },
    };

    private IEnumerable<string> RumorLines(string role, Settlement s)
    {
        if (role != "inn" && role != "elder") yield break;
        // Point at a real neighbor (§2 coherence: rumors reference actual content).
        for (int r = 1; r <= 3; r++)
        {
            for (int dy = -r; dy <= r; dy++)
                for (int dx = -r; dx <= r; dx++)
                {
                    if (Math.Max(Math.Abs(dx), Math.Abs(dy)) != r) continue;
                    if (_frontier.Settlements.InCell(s.CellX + dx, s.CellY + dy) is not { } other) continue;
                    string ns = dy < 0 ? "north" : dy > 0 ? "south" : "";
                    string ew = dx < 0 ? "west" : dx > 0 ? "east" : "";
                    yield return $"They say {other.Name} lies to the {ns}{ew} of here.";
                    yield return $"A peddler came through from {other.Name} last season.";
                    yield break;
                }
        }
        yield return "Beyond us? Just the wilds, far as anyone's sailed.";
    }

    /// <summary>Tier/role shop stock picked from shipped items — data-driven,
    /// so content expansion feeds frontier shops for free.</summary>
    private List<string> ShopStock(string role, int tier, ulong h)
    {
        if (role is not ("trader" or "smith" or "inn")) return new List<string>();
        IEnumerable<ItemDef> pool = role switch
        {
            "trader" => Data.Items.Values.Where(i =>
                i.Kind is ItemKind.Consumable or ItemKind.Tool && i.Price > 0 && i.Price <= 90 + tier * 120),
            "smith" => Data.Items.Values.Where(i =>
                i.Kind is ItemKind.Weapon or ItemKind.Armor && i.Price > 0 && i.Price <= 250 + tier * 350),
            _ => Data.Items.Values.Where(i =>
                i.Kind == ItemKind.Consumable && i.HealHp > 0 && i.Price <= 60),
        };
        var sorted = pool.Select(i => i.Id).OrderBy(id => id, StringComparer.Ordinal).ToList();
        var stock = new List<string>();
        int want = Math.Min(sorted.Count, 4 + tier * 2);
        for (int k = 0; k < want && sorted.Count > 0; k++)
        {
            int pick = (int)(StableId.Mix(h + (ulong)k + 40) % (ulong)sorted.Count);
            stock.Add(sorted[pick]);
            sorted.RemoveAt(pick);
        }
        return stock;
    }

    // ------------------------------------------------------------- contracts

    /// <summary>Ensure the settlement's daily cull contract exists and is the
    /// one this NPC offers (innkeepers and elders post work; D10 day index).</summary>
    public void RefreshContract(NpcDef def)
    {
        if (!def.Id.StartsWith("gen:inn:") && !def.Id.StartsWith("gen:elder:")) return;
        string settlementId = def.Id.Split(':')[2] + ":" + def.Id.Split(':')[3];
        string questId = $"contract:{settlementId}:{DayIndex}";
        if (!Data.Quests.ContainsKey(questId))
        {
            ulong h = StableId.Combine(
                StableId.Combine(StableId.Domain(Seed, "contract"),
                    StableId.Domain(0, settlementId)),
                (ulong)DayIndex);
            var monsters = FrontierMonsterPool();
            string target = monsters[(int)(h % (ulong)monsters.Count)];
            int count = 4 + (int)(StableId.Mix(h + 1) % 5);
            var mdef = Data.Monsters[target];
            Data.Quests[questId] = new QuestDef
            {
                Id = questId,
                Name = $"Bounty: {mdef.Name}s",
                Kind = QuestKind.Kill,
                Giver = def.Id,
                Offer = $"The wilds press close. Thin out the {mdef.Name}s — {count} heads will do.",
                TurnIn = "That's honest work. The purse is yours.",
                TargetMonster = target,
                TargetCount = count,
                RewardGil = 40 + count * 12 + mdef.Level * 8,
                RewardXp = 60 + count * 15 + mdef.Level * 12,
            };
        }
        def.Quests.RemoveAll(q => q.StartsWith("contract:"));
        def.Quests.Add(questId);
    }

    /// <summary>Monster kinds that actually roam the frontier (coherence rule).</summary>
    private List<string> FrontierMonsterPool()
        => WildTables.Values.SelectMany(v => v).Distinct()
            .Where(Data.Monsters.ContainsKey)
            .OrderBy(m => m, StringComparer.Ordinal).ToList();

    // ------------------------------------------------------------- wild spawns

    private static readonly Dictionary<Biome, string[]> WildTables = new()
    {
        [Biome.Grassland] = new[] { "leaf_wisp", "bramble_wolf", "hill_brute" },
        [Biome.Forest] = new[] { "gloom_wisp", "dire_wolf", "bramble_wolf" },
        [Biome.Jungle] = new[] { "marsh_stalker", "dire_wolf", "venom_scorpion" },
        [Biome.Swamp] = new[] { "bog_slime", "marsh_wisp", "marsh_stalker" },
        [Biome.Desert] = new[] { "dune_jackal", "dune_scorpion", "sun_wisp" },
        [Biome.Canyon] = new[] { "venom_scorpion", "rock_scuttler", "dune_jackal" },
        [Biome.Snowfield] = new[] { "snow_wolf", "frost_wisp", "snow_bat" },
        [Biome.Glacier] = new[] { "frost_golem", "frost_crab", "frost_wisp" },
        [Biome.Hills] = new[] { "hill_brute", "clay_golem", "rock_scuttler" },
        [Biome.CrystalWaste] = new[] { "rust_golem", "blood_wisp", "obsidian_golem" },
    };

    private void PopulateWilds(int tx, int ty)
    {
        int cellX = FloorDiv(tx, WildCell), cellY = FloorDiv(ty, WildCell);
        for (int dy = -1; dy <= 1; dy++)
            for (int dx = -1; dx <= 1; dx++)
                PopulateWildCell(cellX + dx, cellY + dy);
    }

    private void PopulateWildCell(int cellX, int cellY)
    {
        long key = ((long)cellX << 32) ^ (uint)cellY;
        if (_wildCells.ContainsKey(key)) return;
        var spawned = new List<int>();
        _wildCells[key] = spawned;

        ulong h = StableId.Combine(StableId.Domain(Seed, "wilds"), cellX, cellY);
        var field = _frontierBiomes;
        int packs = 2 + (int)(h % 3);
        for (int i = 0; i < packs; i++)
        {
            int tx = cellX * WildCell + (int)(StableId.Mix(h + (ulong)i * 3 + 1) % WildCell);
            int ty = cellY * WildCell + (int)(StableId.Mix(h + (ulong)i * 3 + 2) % WildCell);
            if (Data.Map.InStaticBounds(tx, ty)) continue;
            if (!Data.Map.IsWalkableTile(tx, ty)) continue;
            // No spawns inside settlement patches.
            if (_frontier.Settlements.TileOverride(tx, ty) >= 0) continue;
            var biome = field.Classify(tx, ty);
            if (!WildTables.TryGetValue(biome, out var table)) continue;
            string kind = table[(int)(StableId.Mix(h + (ulong)i * 3 + 3) % (ulong)table.Length)];
            if (!Data.Monsters.TryGetValue(kind, out var def)) continue;
            SpawnMonsterAt(def, 0, tx, ty, spawnerId: -50);
            spawned.Add(_nextEntityId - 1);
        }
    }

    /// <summary>The wilds thin out again once nobody is near (bounds entity
    /// count on long voyages; repopulation is pure, so nothing is lost).</summary>
    private void SweepWilds()
    {
        var toClear = new List<long>();
        foreach (var (key, ids) in _wildCells)
        {
            int cellX = (int)(key >> 32), cellY = (int)(uint)key;
            long ccx = (long)(cellX * WildCell + WildCell / 2) * SimConstants.UnitsPerTile;
            long ccy = (long)(cellY * WildCell + WildCell / 2) * SimConstants.UnitsPerTile;
            bool anyNear = false;
            foreach (int playerId in _playerIds)
            {
                var p = _entities[playerId];
                if (p.MapId != 0) continue;
                long dx = p.X - ccx, dy = p.Y - ccy;
                long r = (long)WildDespawnRadius * SimConstants.UnitsPerTile;
                if (dx * dx + dy * dy <= r * r) { anyNear = true; break; }
            }
            if (anyNear) continue;
            foreach (int id in ids)
            {
                if (_entities.TryGetValue(id, out var m) && m.IsMonster && m.SpawnerId == -50)
                {
                    _entities.Remove(id);
                    _entityOrder.Remove(id);
                }
            }
            toClear.Add(key);
        }
        foreach (long key in toClear)
            _wildCells.Remove(key);
    }
}
